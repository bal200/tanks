(c) Robotality UG (haftungsbeschraenkt) 2013

USAGE
************

I made these tile sets for quick and easy prototyping. They both use a different bitwise auto tiling algorithm which were derived from the following tutorials:
http://www.saltgames.com/2010/a-bitwise-method-for-applying-tilemaps/
http://www.codeproject.com/Articles/106884/Implementing-Auto-tiling-Functionality-in-a-Tile-M

Have fun!
Simon Bachmann

ATTRIBUTION
*************

If you'd like to credit us (this is not required and completely up to you) please link to our website: http://www.robotality.com

LICENSE
*************

This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA


